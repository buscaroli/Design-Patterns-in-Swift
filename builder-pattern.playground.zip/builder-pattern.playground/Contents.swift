/* DESIGN PATTERNS IN SWIFT
    - Builder Pattern
 
 Creating a class with many initializers that take a large amount of arguments can cause problems and confusion.
 If we find ourselves in this situation we could instead implement the Builder Pattern, this means using piecewise construction: instead of initialize the entire object with a single massive initializer, we call different methods off a special component called the Builder. The Builder is a component that provides an API for constructing the object step-by-step.
 
 */

func intro() {
    print("~~~ Basic Html rendered with simple functions ~~~")
    /* Suppose you are working on a simple webserver and that you want to return some very simple HTML: you can just ember the text in a tag as below, and that's simple to do
    */
    let hello = "hello"
    var result = "<p>\(hello)</p>\n"
    print (result)
    
    /* Suppose you want to implement something a litlle bit more complicated, like implementing an unordered list
     */
    let words = ["apples", "bananas", "strawberries"]
    result = "<ul>\n"
    for word in words {
        result.append("<li>\(word)</li>\n")
    }
    result.append("</ul>\n")
    print(result)
    
    /* If you want to keep implementing other tags, you'll want to work with a object oriented representation of HTML, that's possible thanks to the Builder Pattern
     */
    
}

intro()

/* Builder Pattern: we are going to build an Object Oriented structure called HtmlElement for defining the different HTML elements, keeping in mind that one elemenet can contain other elements.
 Then we will build an HTML Builder called HtmlBuilder that is a dedicated component for arranging all of the elements in a tree.
 */

class HtmlElement: CustomStringConvertible {
    var name = "" // default value
    var text = "" // default value
    var elements = [HtmlElement]() // an element can contain other elements
    private let indentSize = 2
    
    init() {} // will be using the default values of ""
    init(name: String, text: String) {
        self.name = name
        self.text = text
    }
    
    private func description(_ indent: Int) -> String {
        var result = ""
        let i = String(repeating: " ", count: indent)
        result += "\(i)<\(name)>"
        result += "\n"
        
        if !text.isEmpty {
            result += String(repeating: " ", count: indent+2)
            result += text
            result += "\n"
        }
        
        // children
        for e in elements {
            result += e.description(indent+2)
        }
        
        result += "\(i)</\(name)>"
        result += "\n"
            
        return result
    }
    
    public var description: String {
        return description(0)
    }
}

class HtmlBuilder: CustomStringConvertible {
    private let rootName: String
    var root = HtmlElement()
    
    init(rootName: String) {
        self.rootName = rootName
        root.name = rootName
    }
    
    func addChild(name: String, text: String) {
        let e = HtmlElement(name: name, text: text)
        root.elements.append(e)
    
    }
    
    var description: String {
        return root.description
    }
    
    // method to clear the builder. The builder has an internal state that keeps building up and needs to be cleared/reset
    func clear() {
        root = HtmlElement(name: rootName, text: "")
    }
}


func main() {
    print("~~~ HTML tree implemented with the Builder Pattern ~~~")
    
    let builder = HtmlBuilder(rootName: "ul")
    builder.addChild(name: "li", text: "courgettes")
    builder.addChild(name: "li", text: "carrots")
    builder.addChild(name: "li", text: "aubergines")
    print(builder)
}

main()

